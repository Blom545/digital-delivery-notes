import React from 'react';
import ReactDOM from 'react-dom/client'; // Changed from 'react-dom'
import App from './App.jsx';
import { AuthProvider } from './AuthProvider';
import './index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <AuthProvider>
    <App />
  </AuthProvider>
);