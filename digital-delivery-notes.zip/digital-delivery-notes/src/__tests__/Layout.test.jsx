// src/__tests__/Layout.test.jsx
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import Layout from '../Layout';
import { AuthProvider } from '../AuthProvider';
import { DarkModeProvider } from '../DarkModeContext';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

// Mock Outlet so we can test just the layout
jest.mock('react-router-dom', () => {
  const original = jest.requireActual('react-router-dom');
  return {
    ...original,
    Outlet: () => <div data-testid="mock-outlet" />,
  };
});

// Mock ToastContainer to suppress toast rendering
jest.mock('react-toastify', () => ({
  toast: {
    success: jest.fn(),
    error: jest.fn(),
  },
  ToastContainer: () => <div />,
}));

// Mock Auth Context (with a fake user)
jest.mock('../AuthProvider', () => {
  const actual = jest.requireActual('../AuthProvider');
  return {
    ...actual,
    useAuth: () => ({
      user: { email: 'test@topfruit.co.za', role: 'admin' },
      logout: jest.fn(),
      loading: false,
    }),
  };
});

describe('Layout Component', () => {
  const renderLayout = (initialEntries = ['/layout/menu']) =>
    render(
      <MemoryRouter initialEntries={initialEntries} initialIndex={0}>
        <DarkModeProvider>
          <Routes>
            <Route path="/layout/*" element={<Layout />} />
          </Routes>
        </DarkModeProvider>
      </MemoryRouter>
    );

  test('renders the sidebar and main header', () => {
    renderLayout();
    expect(screen.getByText(/TopFruit App/i)).toBeInTheDocument();
    expect(screen.getByRole('img', { name: /top fruit logo/i })).toBeInTheDocument();
  });

  test('shows the user email and role', () => {
    renderLayout();
    expect(screen.getByText(/test@topfruit.co.za/i)).toBeInTheDocument();
    expect(screen.getByText(/\(Role: admin\)/i)).toBeInTheDocument();
  });

  test('toggles dark mode', () => {
    renderLayout();
    const toggle = screen.getByRole('checkbox');
    expect(toggle).not.toBeChecked();
    fireEvent.click(toggle);
    expect(toggle).toBeChecked();
    // Verify dark class (mimics DarkModeContext behavior)
    expect(document.documentElement.classList.contains('dark')).toBe(true);
  });

  test('sidebar collapse/expand works', async () => {
    renderLayout();
    const toggleButton = screen.getByLabelText(/collapse sidebar/i);
    fireEvent.click(toggleButton);

    await waitFor(() => {
      // Check if sidebar content (e.g., logo or menu items) is hidden
      expect(screen.queryByText('TopFruit')).not.toBeInTheDocument(); // Adjust based on actual hidden content
    }, { timeout: 1000 });

    // Ensure button persists
    expect(toggleButton).toBeInTheDocument();
  });

  test('"Back to Main Menu" button is hidden on menu route', () => {
    renderLayout(['/menu']);
    expect(screen.queryByText(/Back to Main Menu/i)).not.toBeInTheDocument();
  });
});