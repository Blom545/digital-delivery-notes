import { useState, useEffect } from 'react';
import { useAuth } from './AuthProvider';
import { collection, getDocs } from 'firebase/firestore';
import { db } from './firebase';
import { useNavigate } from 'react-router-dom';
import { useDarkMode } from './DarkModeContext';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';

export default function HistoryPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { darkMode } = useDarkMode();
  const [userNotes, setUserNotes] = useState([]);
  const [previewData, setPreviewData] = useState(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBusinessUnit, setFilterBusinessUnit] = useState('all');
  const [filterSeason, setFilterSeason] = useState('all');

  useEffect(() => {
    if (!user) return;
    fetchUserNotes();
  }, [user]);

  const fetchUserNotes = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'deliveryNotes'));
      const notes = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() }))
        .filter(data => data.from === user.email || user.email === 'dihanb@topfruit.co.za');
      setUserNotes(notes);
    } catch (err) {
      console.error('Error fetching user notes:', err);
    }
  };

  const handleRefresh = () => {
    fetchUserNotes();
  };

  const handlePreview = (note) => {
    setPreviewData(note);
    setIsPreviewOpen(true);
  };

  const handleDownload = () => {
    if (!previewData) return;
    const tempContainer = document.createElement('div');
    tempContainer.style.position = 'absolute';
    tempContainer.style.left = '-9999px';
    document.body.appendChild(tempContainer);

    tempContainer.innerHTML = `
      <div class="p-6">
        ${previewData.to ? `<p><strong>To:</strong> ${previewData.to}</p>` : ''}
        ${previewData.from ? `<p><strong>From:</strong> ${previewData.from}</p>` : ''}
        ${previewData.date ? `<p><strong>Date:</strong> ${previewData.date}</p>` : ''}
        ${previewData.season ? `<p><strong>Season:</strong> ${previewData.season}</p>` : ''}
        ${previewData.businessUnit ? `<p><strong>Business Unit:</strong> ${previewData.businessUnit}</p>` : ''}
        ${previewData.deliveryNumber ? `<p><strong>Delivery Note Number:</strong> ${previewData.deliveryNumber}</p>` : ''}
        ${previewData.emailTo ? `<p><strong>Email To:</strong> ${previewData.emailTo}</p>` : ''}
        ${previewData.items.length ? `
          <h3 class="text-lg font-semibold mt-4">Items:</h3>
          <table class="w-full border-collapse border border-gray-400 text-sm">
            <thead>
              <tr>
                <th>Fruit Type</th>
                <th>Variety</th>
                <th>Rootstock</th>
                <th>Block</th>
                <th>Import/Clone Number</th>
                <th>Quantity</th>
                <th>Material Type</th>
              </tr>
            </thead>
            <tbody>
              ${previewData.items.map(item => `
                <tr>
                  <td>${item.fruitType || ''}</td>
                  <td>${item.variety || ''}</td>
                  <td>${item.rootstock || ''}</td>
                  <td>${item.block || ''}</td>
                  <td>${item.importCloneNumber || ''}</td>
                  <td>${item.quantity || ''}</td>
                  <td>${item.materialType || ''}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        ` : ''}
        ${previewData.signature ? `<p class="font-semibold text-gray-700 mb-2">Signature:</p><img src="${previewData.signature}" alt="Signature" />` : ''}
        ${previewData.signerName ? `<p><strong>Signer Name:</strong> ${previewData.signerName}</p>` : ''}
      </div>
    `;

    html2canvas(tempContainer).then((canvas) => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF();
      pdf.addImage(imgData, 'PNG', 10, 10, 190, 0);
      pdf.save(`delivery-note-${previewData.deliveryNumber}.pdf`);
    });

    document.body.removeChild(tempContainer);
    setIsPreviewOpen(false);
  };

  const handleExcelExport = () => {
    const filtered = filteredNotes.map(note => {
      const base = {
        'Delivery Number': note.deliveryNumber,
        'Date': note.date || '',
        'Season': note.season || '',
        'Business Unit': note.businessUnit || '',
        'From': note.from || '',
        'To': note.to || '',
        'Email To': note.emailTo || '',
        'Signer Name': note.signerName || '',
      };
      return note.items.map(item => ({
        ...base,
        'Fruit Type': item.fruitType || '',
        'Variety': item.variety || '',
        'Rootstock': item.rootstock || '',
        'Block': item.block || '',
        'Import/Clone Number': item.importCloneNumber || '',
        'Quantity': item.quantity || '',
        'Material Type': item.materialType || '',
      }));
    }).flat();

    const ws = XLSX.utils.json_to_sheet(filtered);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Delivery Notes');
    XLSX.writeFile(wb, 'delivery-notes-export.xlsx');
  };

  const filteredNotes = userNotes.filter(note => {
    const matchesSearch = note.deliveryNumber?.toLowerCase().includes(searchTerm.toLowerCase()) || !searchTerm;
    const matchesBU = filterBusinessUnit === 'all' || note.businessUnit === filterBusinessUnit;
    const matchesSeason = filterSeason === 'all' || note.season === filterSeason;
    return matchesSearch && matchesBU && matchesSeason;
  });

  const seasons = [...new Set(userNotes.map(note => note.season).filter(Boolean))];

  return (
    <div className={`p-6 ${darkMode ? 'bg-gray-900 text-gray-200' : 'bg-gray-50 text-gray-800'} rounded-xl shadow-lg`}>
      <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Delivery Note History</h1>
      <div className="mb-4 flex flex-col md:flex-row gap-4">
        <button onClick={handleRefresh} className={`bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 ${darkMode ? 'hover:bg-blue-800' : ''}`}>Refresh</button>
        <input
          type="text"
          placeholder="Search by Delivery Number..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className={`border p-2 rounded w-full md:w-1/3 ${darkMode ? 'bg-gray-700 text-gray-200 border-gray-600' : 'bg-white text-gray-800 border-gray-300'}`}
        />
        <select
          value={filterBusinessUnit}
          onChange={(e) => setFilterBusinessUnit(e.target.value)}
          className={`border p-2 rounded w-full md:w-1/4 ${darkMode ? 'bg-gray-700 text-gray-200 border-gray-600' : 'bg-white text-gray-800 border-gray-300'}`}
        >
          <option value="all">All Units</option>
          <option value="Pome">Pome</option>
          <option value="Stone">Stone</option>
          <option value="Grapes">Grapes</option>
        </select>
        <select
          value={filterSeason}
          onChange={(e) => setFilterSeason(e.target.value)}
          className={`border p-2 rounded w-full md:w-1/4 ${darkMode ? 'bg-gray-700 text-gray-200 border-gray-600' : 'bg-white text-gray-800 border-gray-300'}`}
        >
          <option value="all">All Seasons</option>
          {seasons.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <button onClick={handleExcelExport} className={`bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 ${darkMode ? 'hover:bg-green-800' : ''}`}>Export to Excel</button>
      </div>

      {filteredNotes.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse border border-gray-400 text-sm">
            <thead className="bg-gray-100 dark:bg-gray-700">
              <tr>
                <th className="border px-2 py-1 text-gray-800 dark:text-white">Delivery Number</th>
                <th className="border px-2 py-1 text-gray-800 dark:text-white">Date</th>
                <th className="border px-2 py-1 text-gray-800 dark:text-white">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredNotes.map((note) => (
                <tr key={note.id} className="bg-white dark:bg-gray-700">
                  <td className="border px-2 py-1">{note.deliveryNumber}</td>
                  <td className="border px-2 py-1">{note.date || 'N/A'}</td>
                  <td className="border px-2 py-1">
                    <button
                      onClick={() => handlePreview(note)}
                      className="bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700"
                    >
                      Preview
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-gray-600 dark:text-gray-300">No delivery notes found.</p>
      )}

      {isPreviewOpen && previewData && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg max-w-4xl w-full max-h-[80vh] overflow-y-auto">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Preview: {previewData.deliveryNumber}</h2>
            <div className="p-6 text-gray-800 dark:text-gray-200">
              <p><strong>To:</strong> {previewData.to}</p>
              <p><strong>From:</strong> {previewData.from}</p>
              <p><strong>Date:</strong> {previewData.date}</p>
              <p><strong>Season:</strong> {previewData.season}</p>
              <p><strong>Business Unit:</strong> {previewData.businessUnit}</p>
              <p><strong>Email To:</strong> {previewData.emailTo}</p>
              <p><strong>Delivery Note Number:</strong> {previewData.deliveryNumber}</p>
              <h3 className="mt-4 font-semibold">Items</h3>
              <table className="w-full border border-gray-400 mt-2 text-sm">
                <thead className="bg-gray-100 dark:bg-gray-700">
                  <tr>
                    <th className="border px-2 py-1">Fruit Type</th>
                    <th className="border px-2 py-1">Variety</th>
                    <th className="border px-2 py-1">Rootstock</th>
                    <th className="border px-2 py-1">Block</th>
                    <th className="border px-2 py-1">Import/Clone Number</th>
                    <th className="border px-2 py-1">Quantity</th>
                    <th className="border px-2 py-1">Material Type</th>
                  </tr>
                </thead>
                <tbody>
                  {previewData.items.map((item, i) => (
                    <tr key={i}>
                      <td className="border px-2 py-1">{item.fruitType}</td>
                      <td className="border px-2 py-1">{item.variety}</td>
                      <td className="border px-2 py-1">{item.rootstock}</td>
                      <td className="border px-2 py-1">{item.block}</td>
                      <td className="border px-2 py-1">{item.importCloneNumber}</td>
                      <td className="border px-2 py-1">{item.quantity}</td>
                      <td className="border px-2 py-1">{item.materialType}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {previewData.signature && (
                <div className="mt-4">
                  <p className="font-semibold text-gray-700 dark:text-gray-300">Signature:</p>
                  <img src={previewData.signature} alt="Signature" className="border rounded max-w-xs" />
                </div>
              )}
              {previewData.signerName && <p className="mt-2"><strong>Signer Name:</strong> {previewData.signerName}</p>}
            </div>
            <div className="flex justify-end gap-4 mt-6">
              <button
                onClick={handleDownload}
                className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
              >
                Download
              </button>
              <button
                onClick={() => setIsPreviewOpen(false)}
                className="bg-gray-300 dark:bg-gray-700 dark:text-white text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}