import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useState, useRef, useEffect } from 'react';
import SignatureCanvas from 'react-signature-canvas';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { collection, addDoc, getDocs, Timestamp, doc, deleteDoc } from 'firebase/firestore';
import { db } from './firebase';
import { useAuth } from './AuthProvider';
import { analytics } from './firebase';
import { logEvent } from 'firebase/analytics';
import { useNavigate } from 'react-router-dom';
import { useDarkMode } from './DarkModeContext';
import emailjs from 'emailjs-com';

// Custom input style to handle text overflow
const inputStyle = `p-2 border rounded text-sm md:text-base w-full max-w-xs overflow-x-auto whitespace-nowrap`;

export default function DeliveryNoteForm() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { darkMode } = useDarkMode();
  const ADMIN_EMAIL = "dihanb@topfruit.co.za";
  const [userNotes, setUserNotes] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [drafts, setDrafts] = useState(() => {
    const savedDrafts = localStorage.getItem('deliveryDrafts');
    return savedDrafts ? JSON.parse(savedDrafts) : [];
  });
  const [editingDraftId, setEditingDraftId] = useState(null);
  const [formData, setFormData] = useState({
    to: '', date: '', from: '', season: '', businessUnit: '', deliveryNumber: '', emailTo: '',
    items: [{ 
      fruitType: '', 
      certificateNumber: '', 
      blockNumber: '', 
      blockStatus: '', 
      variety: '', 
      cloneImportNumber: '', 
      materialType: '', 
      certificateCategory: '', 
      quantity: '', 
      rootstock: '', 
      block: '', 
      importCloneNumber: '' 
    }],
    signature: null, 
    signerName: '',
  });
  const [lookupData, setLookupData] = useState([]);
  const [fruitTypes, setFruitTypes] = useState([]);
  const [rowDropdowns, setRowDropdowns] = useState({});
  const sigPad = useRef(null);
  const deliveryNumberRef = useRef({});
  const [isSigEmpty, setIsSigEmpty] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchUserNotes();
  }, [user]);

  useEffect(() => {
    if (!user) return;
    fetchDrafts();
  }, [user]);

  const fetchUserNotes = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'deliveryNotes'));
      const notes = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() }))
        .filter(data => data.from === user.email || user.email === ADMIN_EMAIL);
      setUserNotes(notes);
    } catch (err) {
      console.error('Error fetching user notes:', err);
      toast.error('❌ Failed to fetch user notes due to permissions. Contact admin.', { autoClose: 5000 });
    }
  };

  const fetchDrafts = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'draftDeliveryNotes'));
      const fetchedDrafts = snapshot.docs
        .map(doc => ({ id: doc.id, data: { ...doc.data(), id: doc.id }, timestamp: doc.data().createdAt.toDate().toISOString() }))
        .filter(draft => draft.data.user === user.email || user.email === ADMIN_EMAIL);
      const mergedDrafts = [...fetchedDrafts, ...drafts.filter(d => !fetchedDrafts.some(fd => fd.id === d.id))];
      setDrafts(mergedDrafts);
      localStorage.setItem('deliveryDrafts', JSON.stringify(mergedDrafts));
    } catch (err) {
      console.error('Error fetching drafts:', err);
      toast.error('❌ Failed to fetch drafts due to permissions. Contact admin.', { autoClose: 5000 });
    }
  };

  useEffect(() => {
    const storedSequences = localStorage.getItem('deliverySequences');
    deliveryNumberRef.current = storedSequences ? JSON.parse(storedSequences) : {};
    console.log('Delivery number sequences loaded:', deliveryNumberRef.current);
  }, []);

  useEffect(() => {
    if (editingDraftId) {
      const draft = drafts.find(d => d.id === editingDraftId);
      if (draft) {
        setFormData(draft.data);

        if (!draft.data.deliveryNumber && draft.data.season && draft.data.businessUnit) {
          const year = parseInt(draft.data.season);
          if (!isNaN(year) && year >= 2000 && year <= 2100) {
            const key = `${draft.data.businessUnit}-${draft.data.season}`;
            const currentSequence = deliveryNumberRef.current[key] || 0;
            const paddedSequence = String(currentSequence + 1).padStart(3, '0');
            const newDeliveryNumber = `${draft.data.businessUnit}-${draft.data.season}-${paddedSequence}`;
            setFormData(prev => ({ ...prev, deliveryNumber: newDeliveryNumber }));
          }
        }

        const newRowDropdowns = {};
        draft.data.items.forEach((item, index) => {
          const selectedFruit = lookupData.find(l => l.fruitType === item.fruitType);
          newRowDropdowns[index] = {
            varieties: selectedFruit ? selectedFruit.varieties || [] : [],
            rootstocks: selectedFruit ? selectedFruit.rootstocks || [] : [],
          };
        });
        setRowDropdowns(newRowDropdowns);
      }
    }
  }, [editingDraftId, drafts, lookupData]);

  useEffect(() => {
  fetch('/lookupData.json')
    .then((res) => res.json())
    .then((data) => {
      let filteredData;

      if (formData.businessUnit === 'Plant Material') {
        filteredData = data;
        setFruitTypes(data.map(item => item.fruitType)); // Includes A-APPLE, etc.
      } else {
        const buFruitMap = {
          Pome: ['A-APPLE', 'P-PEAR'],
          Stone: ['N-NECTARINE', 'S-PEACH', 'K-APRICOTS', 'R-PLUMS', 'C-CHERRIES', 'X-INTERSPECIFIC PLUMS'],
          Grapes: ['T-TABLE GRAPES'],
        };

        const allowedFruitTypes = buFruitMap[formData.businessUnit] || [];
        filteredData = data.filter(item => allowedFruitTypes.includes(item.fruitType));
        setFruitTypes(allowedFruitTypes);
      }

      setLookupData(filteredData);

      const newRowDropdowns = {};
      formData.items.forEach((item, index) => {
        const selectedFruit = filteredData.find(l => l.fruitType === item.fruitType);
        newRowDropdowns[index] = {
          varieties: selectedFruit ? selectedFruit.varieties || [] : [],
          rootstocks: selectedFruit ? selectedFruit.rootstocks || [] : [],
        };
      });

      setRowDropdowns(newRowDropdowns);
    })
    .catch(err => console.error('Error loading lookupData:', err));
}, [formData.businessUnit, formData.items]);


  useEffect(() => {
    const syncOfflineQueue = async () => {
      const queue = JSON.parse(localStorage.getItem('offlineQueue') || '[]');
      if (queue.length > 0 && navigator.onLine) {
        for (const data of queue) {
          try {
            await addDoc(collection(db, 'deliveryNotes'), data);
            toast.success(`Synced offline submission ${data.deliveryNumber}`);
            localStorage.setItem('offlineQueue', JSON.stringify(queue.filter(q => q !== data)));
          } catch (err) {
            console.error('Failed to sync offline data:', err);
            toast.error('❌ Failed to sync offline data. Retrying later.');
            break;
          }
        }
      }
    };

    const handleOnline = () => syncOfflineQueue();
    const handleOffline = () => console.log('Offline mode activated');

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleFruitTypeChange = (value, index) => {
    const selectedFruit = lookupData.find(item => item.fruitType === value);
    const newItems = [...formData.items];
    newItems[index].fruitType = value;
    newItems[index].variety = '';
    newItems[index].certificateCategory = ''; // Reset for Plant Material
    newItems[index].rootstock = ''; // Reset for non-Plant Material
    setFormData((prev) => ({ ...prev, items: newItems }));
    setRowDropdowns(prev => ({
      ...prev, [index]: selectedFruit ? { varieties: selectedFruit.varieties || [], rootstocks: selectedFruit.rootstocks || [] } : { varieties: [], rootstocks: [] },
    }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleItemChange = (index, e) => {
    const { name, value } = e.target;
    const newItems = [...formData.items];
    newItems[index][name] = value;
    setFormData((prev) => ({ ...prev, items: newItems }));
  };

  const addItem = () => {
    setFormData((prev) => ({
      ...prev, items: [...prev.items, { 
        fruitType: '', 
        certificateNumber: '', 
        blockNumber: '', 
        blockStatus: '', 
        variety: '', 
        cloneImportNumber: '', 
        materialType: '', 
        certificateCategory: '', 
        quantity: '', 
        rootstock: '', 
        block: '', 
        importCloneNumber: '' 
      }],
    }));
  };

  const removeItem = (index) => {
    const newItems = formData.items.filter((_, i) => i !== index);
    setFormData((prev) => ({ ...prev, items: newItems }));
  };

  const clearSignature = () => {
    if (sigPad.current) sigPad.current.clear();
    setIsSigEmpty(true);
    setFormData((prev) => ({ ...prev, signature: null }));
  };

  const onEndSignature = () => {
    if (sigPad.current) {
      const isEmpty = sigPad.current.isEmpty();
      setIsSigEmpty(isEmpty);
      if (!isEmpty) {
        const signatureData = sigPad.current.getTrimmedCanvas().toDataURL('image/png');
        setFormData((prev) => ({ ...prev, signature: signatureData }));
      }
    }
  };

  const saveDraft = () => {
    const draftId = editingDraftId || Date.now().toString();
    const draft = {
      id: draftId,
      data: {
        ...formData,
        deliveryNumber: formData.deliveryNumber || '', // Ensure number is saved
      },
      timestamp: new Date().toISOString(),
    };

    const updatedDrafts = [...drafts.filter(d => d.id !== editingDraftId), draft];
    setDrafts(updatedDrafts);
    localStorage.setItem('deliveryDrafts', JSON.stringify(updatedDrafts));
    toast.success('Draft saved successfully!', { autoClose: 5000 });
    setEditingDraftId(null);
  };

  const loadDraft = (id) => {
    setEditingDraftId(id);
  };

  const deleteDraft = (id) => {
    const updatedDrafts = drafts.filter(d => d.id !== id);
    setDrafts(updatedDrafts);
    localStorage.setItem('deliveryDrafts', JSON.stringify(updatedDrafts));
    if (editingDraftId === id) setEditingDraftId(null);
    toast.success('Draft deleted!', { autoClose: 5000 });
  };

  const validateForm = () => {
    if (!formData.to || !formData.date || !formData.from || !formData.season || !formData.businessUnit) {
      toast.error("❌ Please complete all required header fields (To, From, Date, Season, Business Unit).", { autoClose: 5000 });
      return false;
    }
    const year = parseInt(formData.season);
    if (isNaN(year) || year < 2000 || year > 2100) {
      toast.error('Season must be a valid year (e.g., 2024-2100).', { autoClose: 5000 });
      return false;
    }
    if (!formData.signature) {
      toast.error('❌ Signature required before submitting.', { autoClose: 5000 });
      return false;
    }
    for (let i = 0; i < formData.items.length; i++) {
      const item = formData.items[i];
      if (formData.businessUnit === 'Plant Material') {
        if (!item.fruitType || !item.certificateNumber || !item.blockNumber || !item.blockStatus || !item.variety || !item.cloneImportNumber || !item.materialType || !item.certificateCategory || !item.quantity || Number(item.quantity) <= 0) {
          toast.error(`❌ Row ${i + 1} missing required fields or invalid quantity for Plant Material.`, { autoClose: 5000 });
          return false;
        }
      } else {
        if (!item.fruitType || !item.variety || !item.rootstock || !item.quantity || Number(item.quantity) <= 0) {
          toast.error(`❌ Row ${i + 1} missing required fields or invalid quantity.`, { autoClose: 5000 });
          return false;
        }
      }
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    setIsLoading(true);

    let deliveryNumber = formData.deliveryNumber;

    const isAutoGenerated = deliveryNumber && /^\w+-\d{4}-\d{3}$/.test(deliveryNumber);
    if (!deliveryNumber || (editingDraftId && isAutoGenerated)) {
      const key = `${formData.businessUnit}-${formData.season}`;
      const currentSequence = deliveryNumberRef.current[key] || 0;
      const nextSequence = currentSequence + 1;
      deliveryNumber = `${key}-${String(nextSequence).padStart(3, '0')}`;
      deliveryNumberRef.current[key] = nextSequence;
      localStorage.setItem('deliverySequences', JSON.stringify(deliveryNumberRef.current));
      console.log(`Generated new delivery number: ${deliveryNumber}, Sequence: ${nextSequence}`);
    } else {
      console.log(`Using existing delivery number: ${deliveryNumber}`);
    }

    const finalData = {
      ...formData,
      deliveryNumber,
      createdAt: Timestamp.now(),
      from: user.email,
    };

    if (navigator.onLine) {
      let firestoreSuccess = false;
      try {
        if (db) {
          await addDoc(collection(db, 'deliveryNotes'), finalData);
          firestoreSuccess = true;
          await fetchUserNotes();
        }
      } catch (error) {
        console.error('❌ Firestore error:', error.message || error);
        toast.error('❌ Failed to submit to Firestore due to permissions. Contact admin.', { autoClose: 5000 });
      }

      const tempContainer = document.createElement('div');
      tempContainer.style.position = 'absolute';
      tempContainer.style.left = '-9999px';
      document.body.appendChild(tempContainer);
      tempContainer.innerHTML = `
        <div class="p-6">
          <p><strong>To:</strong> ${formData.to}</p>
          <p><strong>From:</strong> ${formData.from}</p>
        </div>
      `;
      const canvas = await html2canvas(tempContainer);
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF();
      pdf.addImage(imgData, 'PNG', 10, 10, 180, 0);
      document.body.removeChild(tempContainer);

      if (editingDraftId && firestoreSuccess) {
        const updatedDrafts = drafts.filter(d => d.id !== editingDraftId);
        setDrafts(updatedDrafts);
        localStorage.setItem('deliveryDrafts', JSON.stringify(updatedDrafts));

        const firestoreDraft = drafts.find(d => d.id === editingDraftId);
        if (firestoreDraft && firestoreDraft.data.user === user.email) {
          await deleteDoc(doc(db, 'draftDeliveryNotes', firestoreDraft.id));
        }
      }

      localStorage.setItem(`deliveryNote_${formData.deliveryNumber}`, JSON.stringify(finalData));

      toast.success(`✅ Note submitted${firestoreSuccess ? '' : ' (Firestore failed)'}`, { autoClose: 5000 });

      logEvent(analytics, 'delivery_note_submitted', {
        user: user?.email || 'unknown',
        season: formData.season,
        item_count: formData.items.length,
      });
    } else {
      const queue = JSON.parse(localStorage.getItem('offlineQueue') || '[]');
      queue.push(finalData);
      localStorage.setItem('offlineQueue', JSON.stringify(queue));
      toast.info(`Offline submission queued: ${deliveryNumber}`);
    }

    setFormData({
      to: '', date: '', from: '', season: '', businessUnit: '', deliveryNumber: '', emailTo: '',
      items: [{ 
        fruitType: '', 
        certificateNumber: '', 
        blockNumber: '', 
        blockStatus: '', 
        variety: '', 
        cloneImportNumber: '', 
        materialType: '', 
        certificateCategory: '', 
        quantity: '', 
        rootstock: '', 
        block: '', 
        importCloneNumber: '' 
      }],
      signature: null, 
      signerName: '',
    });

    if (sigPad.current) sigPad.current.clear();
    setIsSigEmpty(true);

    if (formData.emailTo && navigator.onLine) {
      emailjs.send('service_6sv9oxf', 'template_6rezv6c', {
        email: formData.emailTo,
        from_name: user.email,
        subject: `Delivery Note ${formData.deliveryNumber}`,
        message: 'PDF not attached. Download manually.',
      }, '4OZBxRs1OJX1TTrMz').then(() => {
        toast.success('✅ Notification email sent!', { autoClose: 5000 });
      }).catch(err => {
        console.error('Email send failed:', err);
        toast.error('❌ Failed to send notification email.', { autoClose: 5000 });
      });
    }

    setIsLoading(false);
  };

  const handleDownloadPDF = async () => {
    const tempContainer = document.createElement('div');
    tempContainer.style.position = 'fixed';
    tempContainer.style.top = '0';
    tempContainer.style.left = '0';
    tempContainer.style.width = '800px';
    tempContainer.style.padding = '24px';
    tempContainer.style.background = '#fff';
    tempContainer.style.zIndex = '9999';
    tempContainer.style.fontFamily = 'Arial, sans-serif';

    // Only show columns with content
    const activeColumns = formData.businessUnit === 'Plant Material'
      ? ['fruitType', 'certificateNumber', 'blockNumber', 'blockStatus', 'variety', 'cloneImportNumber', 'materialType', 'certificateCategory', 'quantity']
      : ['fruitType', 'variety', 'rootstock', 'block', 'importCloneNumber', 'quantity', 'materialType'];
    const columnLabels = {
      fruitType: 'Fruit Type',
      certificateNumber: 'Certificate Number',
      blockNumber: 'Block Number',
      blockStatus: 'Block Status',
      variety: 'Variety',
      cloneImportNumber: 'Clone/Import Number',
      materialType: 'Material Type',
      certificateCategory: 'Certificate Category',
      quantity: 'Quantity',
      rootstock: 'Rootstock',
      block: 'Block',
      importCloneNumber: 'Import/Clone Number'
    };

    // Build the HTML content
    tempContainer.innerHTML = `
      <div style="width:100%;">
        <img src="/logo.png" style="height:200px; margin-bottom:20px;" />
        <p><strong>To:</strong> ${formData.to || ''}</p>
        <p><strong>From:</strong> TopFruit</p>
        <p><strong>Date:</strong> ${formData.date || ''}</p>
        <p><strong>Season:</strong> ${formData.season || ''}</p>
        <p><strong>Business Unit:</strong> ${formData.businessUnit || ''}</p>
        <p><strong>Delivery Note Number:</strong> ${formData.deliveryNumber || ''}</p>
        ${formData.emailTo ? `<p><strong>Email To:</strong> ${formData.emailTo}</p>` : ''}

        ${formData.items && formData.items.length > 0 ? `
          <h3 style="margin-top: 24px;"><strong>Items:</strong></h3>
          <table style="width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 8px;">
            <thead>
              <tr>
                ${activeColumns.map(key => `<th style="border: 1px solid #ccc; padding: 6px; background: #eee;">${columnLabels[key]}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${formData.items.map((item, idx) => `
                <tr style="background-color: ${idx % 2 === 0 ? '#fff' : '#f9f9f9'};">
                  ${activeColumns.map(key => `<td style="border: 1px solid #ccc; padding: 6px;">${item[key] || ''}</td>`).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>
        ` : ''}

        ${formData.signature ? `
          <div style="margin-top: 40px;">
            <p><strong>Signature:</strong></p>
            <img src="${formData.signature}" style="max-width:300px; border: 1px solid #ccc; margin-top: 8px;" />
          </div>
        ` : ''}

        ${formData.signerName ? `
          <p style="margin-top: 12px;"><strong>Signer Name:</strong> ${formData.signerName}</p>
        ` : ''}
      </div>
    `;

    document.body.appendChild(tempContainer);

    // Capture with high-res canvas
    const canvas = await html2canvas(tempContainer, {
  scale: 2,
  useCORS: true
});

const imgData = canvas.toDataURL('image/png');
const pdf = new jsPDF({
  orientation: 'portrait',
  unit: 'px',
  format: 'a4'
});

const pageWidth = pdf.internal.pageSize.getWidth();
const imgProps = pdf.getImageProperties(imgData);
const imgHeight = (imgProps.height * pageWidth) / imgProps.width;

pdf.addImage(imgData, 'PNG', 0, 0, pageWidth, imgHeight);


    pdf.save(`${formData.deliveryNumber || 'delivery-note'}.pdf`);

    document.body.removeChild(tempContainer);
  };

  const resetNumber = () => {
    deliveryNumberRef.current = {};
    localStorage.removeItem('deliverySequences');
    setFormData({
      to: '', date: '', from: '', season: '', businessUnit: '', emailTo: '', deliveryNumber: '',
      items: [{ 
        fruitType: '', 
        certificateNumber: '', 
        blockNumber: '', 
        blockStatus: '', 
        variety: '', 
        cloneImportNumber: '', 
        materialType: '', 
        certificateCategory: '', 
        quantity: '', 
        rootstock: '', 
        block: '', 
        importCloneNumber: '' 
      }],
      signature: null, 
      signerName: '',
    });
    if (sigPad.current) sigPad.current.clear();
    setIsSigEmpty(true);
  };

  const clearFormFields = () => {
    setFormData({
      to: '', date: '', from: '', season: '', businessUnit: '', deliveryNumber: '', emailTo: '',
      items: [{ 
        fruitType: '', 
        certificateNumber: '', 
        blockNumber: '', 
        blockStatus: '', 
        variety: '', 
        cloneImportNumber: '', 
        materialType: '', 
        certificateCategory: '', 
        quantity: '', 
        rootstock: '', 
        block: '', 
        importCloneNumber: '' 
      }],
      signature: null, 
      signerName: '',
    });
    setRowDropdowns({});
    if (sigPad.current) sigPad.current.clear();
    setIsSigEmpty(true);
    toast.success('✅ Form has been cleared.', { autoClose: 5000 });
  };

  return (
  <div className={`p-4 md:p-6 ${darkMode ? 'bg-gray-900 text-gray-200' : 'bg-gray-50 text-gray-800'} rounded-xl shadow-lg border-t-4 border-blue-600 min-h-screen`}>
    <h1 className="text-2xl md:text-3xl font-bold text-default mb-4 md:mb-6">Create New Delivery Note</h1>
    <p className="text-sm md:text-base text-muted mb-4">Logged in as <strong>{user?.email}</strong></p>
    <form onSubmit={handleSubmit} className="space-y-4 md:space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 sm:gap-3 md:gap-4">
          <input name="to" value={formData.to} onChange={handleChange} placeholder="To" className={inputStyle} />
          <input name="date" type="date" value={formData.date} onChange={handleChange} className={inputStyle} />
          <input name="from" value={formData.from} onChange={handleChange} placeholder="From" className={inputStyle} />
          <input name="season" value={formData.season} onChange={handleChange} placeholder="Season (e.g., 2024)" className={inputStyle} pattern="\d{4}" title="Please enter a valid year (e.g., 2024)" />
          <select name="businessUnit" value={formData.businessUnit} onChange={handleChange} className={inputStyle}>
            <option value="">Select Business Unit</option>
            <option value="Pome">Pome</option>
            <option value="Stone">Stone</option>
            <option value="Grapes">Grapes</option>
            <option value="Plant Material">Plant Material</option>
          </select>
          <input name="emailTo" value={formData.emailTo} onChange={handleChange} placeholder="Email To (Optional)" className={inputStyle} type="email" />
        </div>
        <div className="text-md md:text-lg font-medium text-default">
          Delivery Note Number: <span className="font-semibold">
            {formData.deliveryNumber ||
              (formData.season && formData.businessUnit
                ? `${formData.businessUnit}-${formData.season}-${String((deliveryNumberRef.current[`${formData.businessUnit}-${formData.season}`] || 0) + 1).padStart(3, '0')}`
                : 'Not set (enter season and unit)')}
          </span>
        </div>
        <div className="overflow-x-auto">
          <div className="md:hidden">
            {formData.items.map((item, index) => (
              <div key={index} className="border p-2 mb-2 rounded">
                {formData.businessUnit === 'Plant Material' ? (
                  <>
                    <select value={item.fruitType} onChange={(e) => handleFruitTypeChange(e.target.value, index)} className={`${inputStyle} w-full mb-1`}>
                      <option value="">Select Fruit Type</option>
                      {fruitTypes.map((f) => (
                        <option key={f} value={f}>
                          {f === 'A' ? 'Apples' : f === 'P' ? 'Pears' : f === 'S' ? 'Peaches' : f === 'N' ? 'Nectarines' : f === 'X' ? 'Interspecific Plums' : f === 'D' ? 'Almonds' : f === 'K' ? 'Apricots' : f === 'T' ? 'Tablegrapes' : f === 'R' ? 'Plums' : f === 'C' ? 'Cherries' : f}
                        </option>
                      ))}
                    </select>
                    <input name="certificateNumber" value={item.certificateNumber} onChange={(e) => handleItemChange(index, e)} placeholder="Certificate Number" className={`${inputStyle} w-full mb-1`} />
                    <input name="blockNumber" value={item.blockNumber} onChange={(e) => handleItemChange(index, e)} placeholder="Block Number" className={`${inputStyle} w-full mb-1`} />
                    <input name="blockStatus" value={item.blockStatus} onChange={(e) => handleItemChange(index, e)} placeholder="Block Status" className={`${inputStyle} w-full mb-1`} />
                    <select name="variety" value={item.variety} onChange={(e) => handleItemChange(index, e)} className={`${inputStyle} w-full mb-1`}>
                      <option value="">Select Variety</option>
                      {(rowDropdowns[index]?.varieties || []).map((v) => (
                        <option key={v} value={v}>{v}</option>
                      ))}
                    </select>
                    <input name="cloneImportNumber" value={item.cloneImportNumber} onChange={(e) => handleItemChange(index, e)} placeholder="Clone/Import Number" className={`${inputStyle} w-full mb-1`} />
                    <select name="materialType" value={item.materialType} onChange={(e) => handleItemChange(index, e)} className={`${inputStyle} w-full mb-1`}>
  <option value="">Select</option>
  <option value="Buds">Buds</option>
  <option value="Grafts">Grafts</option>
  <option value="Trees">Trees</option>
</select>

                    <select name="certificateCategory" value={item.certificateCategory} onChange={(e) => handleItemChange(index, e)} className={`${inputStyle} w-full mb-1`}>
                      <option value="">Select Category</option>
                      <option value="K">K</option>
                      <option value="B">B</option>
                      <option value="O">O</option>
                    </select>
                    <input name="quantity" type="number" min="1" value={item.quantity} onChange={(e) => handleItemChange(index, e)} placeholder="Quantity" className={`${inputStyle} w-full mb-1`} />
                  </>
                ) : (
                  <>
                    <select value={item.fruitType} onChange={(e) => handleFruitTypeChange(e.target.value, index)} className={`${inputStyle} w-full mb-1`}>
                      <option value="">Select Fruit Type</option>
                      {fruitTypes.map((f) => (
                        <option key={f} value={f}>
                          {f === 'APPLE' ? 'Apples' : f === 'PEAR' ? 'Pears' : f}
                        </option>
                      ))}
                    </select>
                    <select name="variety" value={item.variety} onChange={(e) => handleItemChange(index, e)} className={`${inputStyle} w-full mb-1`}>
                      <option value="">Select Variety</option>
                      {(rowDropdowns[index]?.varieties || []).map((v) => (
                        <option key={v} value={v}>{v}</option>
                      ))}
                    </select>
                    <select name="rootstock" value={item.rootstock} onChange={(e) => handleItemChange(index, e)} className={`${inputStyle} w-full mb-1`}>
                      <option value="">Select Rootstock</option>
                      {(rowDropdowns[index]?.rootstocks || []).map((r) => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                    </select>
                    <input name="block" value={item.block} onChange={(e) => handleItemChange(index, e)} placeholder="Block" className={`${inputStyle} w-full mb-1`} />
                    <input name="importCloneNumber" value={item.importCloneNumber} onChange={(e) => handleItemChange(index, e)} placeholder="Import/Clone Number" className={`${inputStyle} w-full mb-1`} />
                    <input name="quantity" type="number" min="1" value={item.quantity} onChange={(e) => handleItemChange(index, e)} placeholder="Quantity" className={`${inputStyle} w-full mb-1`} />
                    <input name="materialType" value={item.materialType} onChange={(e) => handleItemChange(index, e)} placeholder="Material Type" className={`${inputStyle} w-full mb-1`} />
                  </>
                )}
                <button type="button" onClick={() => removeItem(index)} className="btn-red w-full mt-1">Remove</button>
              </div>
            ))}
          </div>
          <div className="table-wrapper">
        <table className="w-full border-collapse border border-gray-400 text-sm responsive-card hidden md:table">
          <thead className="bg-gray-100 dark:bg-gray-700">
                <tr>
                  {formData.businessUnit === 'Plant Material' ? (
                    <>
                      <th className="border px-2 py-1" data-label="Fruit Type">Fruit Type</th>
                      <th className="border px-2 py-1" data-label="Certificate Number">Certificate Number</th>
                      <th className="border px-2 py-1" data-label="Block Number">Block Number</th>
                      <th className="border px-2 py-1" data-label="Block Status">Block Status</th>
                      <th className="border px-2 py-1" data-label="Variety">Variety</th>
                      <th className="border px-2 py-1" data-label="Clone/Import Number">Clone/Import Number</th>
                      <th className="border px-2 py-1" data-label="Material Type">Material Type</th>
                      <th className="border px-2 py-1" data-label="Certificate Category">Certificate Category</th>
                      <th className="border px-2 py-1" data-label="Quantity">Quantity</th>
                      <th className="border px-2 py-1" data-label="Actions">Actions</th>
                    </>
                  ) : (
                    <>
                      <th className="border px-2 py-1" data-label="Fruit Type">Fruit Type</th>
                      <th className="border px-2 py-1" data-label="Variety">Variety</th>
                      <th className="border px-2 py-1" data-label="Rootstock">Rootstock</th>
                      <th className="border px-2 py-1" data-label="Block">Block</th>
                      <th className="border px-2 py-1" data-label="Import/Clone Number">Import/Clone Number</th>
                      <th className="border px-2 py-1" data-label="Quantity">Quantity</th>
                      <th className="border px-2 py-1" data-label="Material Type">Material Type</th>
                      <th className="border px-2 py-1" data-label="Actions">Actions</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody>
  {formData.items.map((item, index) => (
    <tr
      key={index}
      className={
        index % 2 === 0 ? 'bg-white dark:bg-gray-700' : 'bg-gray-50 dark:bg-gray-800'
      }
    >
      {formData.businessUnit === 'Plant Material' ? (
        <>
          <td className="border p-1" data-label="Fruit Type">
            <select
              value={item.fruitType}
              onChange={(e) => handleFruitTypeChange(e.target.value, index)}
              className={inputStyle}
            >
              <option value="">Select</option>
              {fruitTypes.map((f) => (
                <option key={f} value={f}>
                  {f === 'A' ? 'Apples' :
                   f === 'P' ? 'Pears' :
                   f === 'S' ? 'Peaches' :
                   f === 'N' ? 'Nectarines' :
                   f === 'X' ? 'Interspecific Plums' :
                   f === 'D' ? 'Almonds' :
                   f === 'K' ? 'Apricots' :
                   f === 'T' ? 'Tablegrapes' :
                   f === 'R' ? 'Plums' :
                   f === 'C' ? 'Cherries' : f}
                </option>
              ))}
            </select>
          </td>
          <td className="border p-1" data-label="Certificate Number">
            <input
              name="certificateNumber"
              value={item.certificateNumber}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            />
          </td>
          <td className="border p-1" data-label="Block Number">
            <input
              name="blockNumber"
              value={item.blockNumber}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            />
          </td>
          <td className="border p-1" data-label="Block Status">
            <input
              name="blockStatus"
              value={item.blockStatus}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            />
          </td>
          <td className="border p-1" data-label="Variety">
            <select
              name="variety"
              value={item.variety}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            >
              <option value="">Select Variety</option>
              {(rowDropdowns[index]?.varieties || []).map((v) => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
          </td>
          <td className="border p-1" data-label="Clone/Import Number">
            <input
              name="cloneImportNumber"
              value={item.cloneImportNumber}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            />
          </td>
          <td className="border p-1" data-label="Material Type">
  <select
    name="materialType"
    value={item.materialType}
    onChange={(e) => handleItemChange(index, e)}
    className={inputStyle}
  >
    <option value="">Select</option>
    <option value="Buds">Buds</option>
    <option value="Grafts">Grafts</option>
     <option value="Trees">Trees</option>
  </select>
</td>

          <td className="border p-1" data-label="Certificate Category">
            <select
              name="certificateCategory"
              value={item.certificateCategory}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            >
              <option value="">Select</option>
              <option value="K">K</option>
              <option value="B">B</option>
              <option value="O">O</option>
            </select>
          </td>
          <td className="border p-1" data-label="Quantity">
            <input
              name="quantity"
              type="number"
              min="1"
              value={item.quantity}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            />
          </td>
          <td className="border p-1" data-label="Actions">
            <button
              type="button"
              onClick={() => removeItem(index)}
              className="btn-red"
            >
              Remove
            </button>
          </td>
        </>
      ) : (
        <>
          <td className="border p-1" data-label="Fruit Type">
            <select
              value={item.fruitType}
              onChange={(e) => handleFruitTypeChange(e.target.value, index)}
              className={inputStyle}
            >
              <option value="">Select</option>
              {fruitTypes.map((f) => (
                <option key={f} value={f}>
                  {f === 'APPLE' ? 'Apples' : f === 'PEAR' ? 'Pears' : f}
                </option>
              ))}
            </select>
          </td>
          <td className="border p-1" data-label="Variety">
            <select
              name="variety"
              value={item.variety}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            >
              <option value="">Select Variety</option>
              {(rowDropdowns[index]?.varieties || []).map((v) => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
          </td>
          <td className="border p-1" data-label="Rootstock">
            <select
              name="rootstock"
              value={item.rootstock}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            >
              <option value="">Select Rootstock</option>
              {(rowDropdowns[index]?.rootstocks || []).map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </td>
          <td className="border p-1" data-label="Block">
            <input
              name="block"
              value={item.block}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            />
          </td>
          <td className="border p-1" data-label="Import/Clone Number">
            <input
              name="importCloneNumber"
              value={item.importCloneNumber}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            />
          </td>
          <td className="border p-1" data-label="Quantity">
            <input
              name="quantity"
              type="number"
              min="1"
              value={item.quantity}
              onChange={(e) => handleItemChange(index, e)}
              className={inputStyle}
            />
          </td>
          <td className="border p-1" data-label="Material Type">
            <select
              name="materialType"
              value={item.materialType}
              onChange={(e) => handleItemChange(index, 'materialType', e.target.value)}
              className={inputStyle}
            >
              <option value="">Select</option>
              <option value="Trees">Trees</option>
              <option value="Buds">Buds</option>
              <option value="Grafts">Grafts</option>
            </select>
          </td>
          <td className="border p-1" data-label="Actions">
            <button
              type="button"
              onClick={() => removeItem(index)}
              className="btn-red"
            >
              Remove
            </button>
          </td>
        </>
      )}
    </tr>
  ))}
</tbody>
</table>
</div>
</div>

<button type="button" onClick={addItem} className="btn-blue mt-3">
  + Add Item
</button>

<div className="mt-6">
  <p className="text-lg font-semibold mb-1">Signature:</p>
  <SignatureCanvas
    ref={sigPad}
    penColor="black"
    canvasProps={{ className: "border rounded w-full h-32 bg-white" }}
    onEnd={onEndSignature}
  />
  <div className="flex justify-between mt-2">
    <input
      name="signerName"
      value={formData.signerName}
      onChange={handleChange}
      placeholder="Signer Name"
      className="p-2 border rounded text-sm w-1/2"
    />
    <button type="button" onClick={clearSignature} className="btn-red ml-2">
      Clear Signature
    </button>
  </div>
</div>

<div className="mt-6 flex flex-wrap gap-2">
  <button type="submit" disabled={isLoading} className="btn-green">
    {isLoading ? 'Submitting...' : 'Submit Note'}
  </button>
  <button type="button" onClick={handleDownloadPDF} className="btn-yellow">
    Download PDF
  </button>
  <button type="button" onClick={saveDraft} className="btn-gray">
    Save Draft
  </button>
  <button type="button" onClick={resetNumber} className="btn-gray">
    Reset Number
  </button>
  <button type="button" onClick={clearFormFields} className="btn-gray">
    Clear Form
  </button>
</div>
</form>

<div className="mt-8">
  <h2 className="text-xl font-semibold mb-2">Saved Drafts</h2>
  <ul className="space-y-2">
    {drafts.map(draft => (
      <li key={draft.id} className="border p-2 rounded flex justify-between items-center">
        <div>
          <p className="font-medium">{draft.data.deliveryNumber || 'No Number'}</p>
          <p className="text-sm text-gray-500">{new Date(draft.timestamp).toLocaleString()}</p>
        </div>
        <div className="space-x-2">
          <button onClick={() => loadDraft(draft.id)} className="btn-blue">Load</button>
          <button onClick={() => deleteDraft(draft.id)} className="btn-red">Delete</button>
        </div>
      </li>
    ))}
  </ul>
</div>

<ToastContainer />
</div>
);
}
