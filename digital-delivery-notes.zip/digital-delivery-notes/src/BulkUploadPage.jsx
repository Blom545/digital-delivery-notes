import React, { useState } from 'react';
import { useAuth } from './AuthProvider';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import * as XLSX from 'xlsx';
import { useDarkMode } from './DarkModeContext';
import { collection, addDoc, Timestamp } from 'firebase/firestore';
import { db } from './firebase';

export default function BulkUploadPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { darkMode } = useDarkMode();
  const ADMIN_EMAIL = 'dihanb@topfruit.co.za';
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleBulkUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setIsLoading(true);
    setProgress(10);

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        setProgress(30);

        const workbook = XLSX.read(data, { type: 'array' });
        setProgress(50);

        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' }); // Raw rows with headers
        const jsonRows = XLSX.utils.sheet_to_json(sheet); // Parsed JSON rows

        console.log('Raw rows (with headers):', rows); // Debug all rows
        console.log('Parsed JSON rows:', jsonRows); // Debug parsed data

        if (!jsonRows.length) {
          toast.error('No data found in the sheet.', { autoClose: 5000 });
          setProgress(0);
          setIsLoading(false);
          return;
        }

        // Group rows by to, from, date, and season
        const drafts = {};
        jsonRows.forEach(row => {
          const normalizedRow = {};
          for (const key in row) {
            normalizedRow[key.toLowerCase().trim()] = row[key];
          }

          // Convert date and season to strings
          const dateStr = normalizedRow.date ? String(normalizedRow.date).trim() : '';
          const seasonStr = normalizedRow.season ? String(normalizedRow.season).trim() : '';
          const formattedDate = dateStr ? XLSX.SSF.format('yyyy-mm-dd', parseFloat(dateStr) || new Date(dateStr)) : '';

          // Validate required fields
          if (!normalizedRow.to || !normalizedRow.from || !formattedDate || !seasonStr ||
              normalizedRow.to.trim() === '' || normalizedRow.from.trim() === '' || 
              formattedDate === '' || seasonStr === '') {
            console.warn('Skipping invalid row:', row);
            return;
          }

          // Create a unique key for grouping
          const key = `${normalizedRow.to.trim()}-${normalizedRow.from.trim()}-${formattedDate}-${seasonStr}`;
          if (!drafts[key]) {
            drafts[key] = {
              to: normalizedRow.to.trim(),
              from: normalizedRow.from.trim(),
              date: formattedDate,
              season: seasonStr,
              businessUnit: normalizedRow.businessunit?.trim() || '',
              emailTo: normalizedRow.emailto?.trim() || '',
              signerName: normalizedRow.signername?.trim() || '',
              items: [],
              user: user?.email || 'unknown@user.com',
              createdAt: Timestamp.now()
            };
          }

          // Add item details to the draft
          drafts[key].items.push({
            fruitType: normalizedRow.fruittype?.trim() || '',
            variety: normalizedRow.variety?.trim() || '',
            rootstock: normalizedRow.rootstock?.trim() || '',
            block: normalizedRow.block?.trim() || '',
            importCloneNumber: normalizedRow.importclonenumber?.trim() || '',
            quantity: Number(normalizedRow.quantity) || 0,
            materialType: normalizedRow.materialtype?.trim() || '',
          });
        });

        // Upload each draft
        const draftCollection = collection(db, 'draftDeliveryNotes');
        for (const key in drafts) {
          console.log('Uploading draft:', drafts[key]); // Debug each draft
          await addDoc(draftCollection, drafts[key]);
        }

        setProgress(70);
        toast.success('✅ Drafts uploaded successfully!', { autoClose: 5000 });
      } catch (err) {
        console.error('Bulk upload failed:', err);
        toast.error('❌ Upload failed. See console for details.', { autoClose: 5000 });
      } finally {
        setProgress(100);
        setTimeout(() => setProgress(0), 1000);
        setIsLoading(false);
      }
    };

    reader.readAsArrayBuffer(file);
  };

  return (
    <div className={`max-w-6xl mx-auto p-6 ${darkMode ? 'bg-gray-900 text-gray-200' : 'bg-gray-50 text-gray-800'} min-h-screen`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="Top Fruit Logo" className="h-16 object-contain" />
          <h1 className="text-2xl font-bold text-default">Bulk Excel Upload</h1>
        </div>
      </div>

      {user?.email === ADMIN_EMAIL ? (
        <div className={`p-6 rounded-xl shadow-lg border-t-4 border-blue-600 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
          <div className="flex flex-col gap-4">
            <input
              type="file"
              accept=".xlsx, .xls, .csv"
              onChange={handleBulkUpload}
              className="input"
              disabled={isLoading}
            />
            {isLoading && (
              <div className="mt-4">
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                  <div
                    className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
                <p className="text-sm text-muted mt-1">{progress}%</p>
              </div>
            )}
            <p className="text-sm text-muted">
              {isLoading
                ? 'Uploading...'
                : 'Use the BulkUploadTemplate.xlsx file. Required fields: To, From, Date, Season. Optional: EmailTo, SignerName, BusinessUnit, Items.'}
            </p>
          </div>
        </div>
      ) : (
        <p className="text-muted">Only admins can access bulk upload.</p>
      )}
    </div>
  );
}