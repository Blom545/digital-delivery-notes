import { createContext, useContext, useEffect, useState } from 'react';
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut, updateEmail } from 'firebase/auth';
import { app } from './firebase';
import { doc, getDoc, updateDoc, setDoc } from 'firebase/firestore';
import { db } from './firebase';
import { getDocs, collection, deleteDoc } from 'firebase/firestore';


const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // Track auth loading state
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
      setLoading(true); // Start loading
      if (authUser) {
        try {
          const userRef = doc(db, 'users', authUser.uid);
          const userDoc = await getDoc(userRef);
          if (!userDoc.exists()) {
            // Create a new document with default role if it doesn't exist
            await setDoc(userRef, { email: authUser.email, role: 'user' });
          }
          const userData = userDoc.exists() ? userDoc.data() : { role: 'user' };
          setUser({ ...authUser, role: userData.role, email: userData.email || authUser.email });
        } catch (error) {
          console.error('Error fetching or creating user role:', error);
          setUser({ ...authUser, role: 'user', email: authUser.email }); // Fallback
        }
      } else {
        setUser(null);
      }
      setLoading(false); // End loading
    });
    return () => unsubscribe();
  }, [auth]);

  const login = async (email, password) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userRef = doc(db, 'users', userCredential.user.uid);
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) {
        await setDoc(userRef, { email, role: 'user' });
      }
      const userData = userDoc.exists() ? userDoc.data() : { role: 'user' };
      setUser({ ...userCredential.user, role: userData.role });
    } catch (error) {
      console.error('Login failed:', error.message);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setUser(null);
    } catch (error) {
      console.error('Logout failed:', error.message);
      throw error;
    }
  };

  const updateUser = async (updates) => {
    if (!user) throw new Error('No authenticated user');

    try {
      setLoading(true);
      const userRef = doc(db, 'users', user.uid);

      // Check if document exists, create if it doesn't
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) {
        await setDoc(userRef, { email: user.email, role: user.role });
      }

      // Update email in Firebase Authentication if provided
      if (updates.email && updates.email !== user.email) {
        await updateEmail(auth.currentUser, updates.email);
        setUser((prev) => ({ ...prev, email: updates.email }));
      }

      // Update Firestore document with email and role
      const updateData = {
        email: updates.email || user.email,
        role: updates.role || user.role, // Allow role update
      };
      await updateDoc(userRef, updateData);

      // Fetch updated document to ensure consistency
      const updatedDoc = await getDoc(userRef);
      const updatedData = updatedDoc.exists() ? updatedDoc.data() : {};
      setUser((prev) => ({ ...prev, ...updatedData }));
    } catch (error) {
      console.error('Error updating user:', error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };
  // In AuthProvider.js (inside AuthProvider function, before return):

const getAllUsers = async () => {
  try {
    const snapshot = await getDocs(collection(db, 'users'));
    return snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Failed to fetch users:', error);
    throw error;
  }
};

const addUser = async ({ email, role }) => {
  try {
    const newUserRef = doc(db, 'users', email); // Use email as ID for simplicity
    await setDoc(newUserRef, { email, role });
  } catch (error) {
    console.error('Failed to add user:', error);
    throw error;
  }
};

const deleteUser = async (uid) => {
  try {
    const userRef = doc(db, 'users', uid);
    await deleteDoc(userRef);
  } catch (error) {
    console.error('Failed to delete user:', error);
    throw error;
  }
};


  return (
  <AuthContext.Provider
    value={{
      user, login, logout, updateUser, loading,
      getAllUsers, addUser, deleteUser, // 👈 export new functions
    }}
  >
    {children}
  </AuthContext.Provider>
);
}

export const useAuth = () => useContext(AuthContext);