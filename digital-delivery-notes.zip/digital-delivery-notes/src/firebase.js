// src/firebase.js

import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getAnalytics, isSupported } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyAARXq9-Ti7W8TsGq52_NLLRffNTdvFq04",
  authDomain: "topfruitdeliverynotes.firebaseapp.com",
  projectId: "topfruitdeliverynotes",
  storageBucket: "topfruitdeliverynotes.appspot.com",
  messagingSenderId: "712525279437",
  appId: "1:712525279437:web:ef4bd18997e56d54ee7984"
};

// ✅ Initialize Firebase App
const app = initializeApp(firebaseConfig);

// ✅ Initialize Firestore and Auth
const db = getFirestore(app);
const auth = getAuth(app);

// ✅ Conditional Analytics (prevents issues in Jest/Node environments)
let analytics = null;
isSupported().then((supported) => {
  if (supported) {
    analytics = getAnalytics(app);
  }
});

export { app, db, auth, analytics };
