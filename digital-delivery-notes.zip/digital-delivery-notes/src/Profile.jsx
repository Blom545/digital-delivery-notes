import React, { useState, useEffect } from 'react';
import { useAuth } from './AuthProvider';
import { useDarkMode } from './DarkModeContext';
import { useNavigate } from 'react-router-dom';

export default function Profile() {
  const {
    user,
    updateUser,
    getAllUsers,
    addUser,
    deleteUser
  } = useAuth();
  const { darkMode } = useDarkMode();
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState({ email: '', role: 'user' });
  const [editing, setEditing] = useState(null); // uid of user being edited
  const [error, setError] = useState('');

  useEffect(() => {
    if (!user) navigate('/login');
    if (user?.role === 'admin') loadUsers();
  }, [user]);

  const loadUsers = async () => {
    try {
      const data = await getAllUsers();
      setUsers(data);
    } catch (err) {
      console.error(err);
      setError('Failed to load users.');
    }
  };

  const handleEdit = (uid) => {
    setEditing(uid);
  };

  const handleUpdate = async (uid, updated) => {
    try {
      await updateUser({ ...updated, uid });
      await loadUsers();
      setEditing(null);
    } catch (err) {
      console.error(err);
      setError('Failed to update user.');
    }
  };

  const handleDelete = async (uid) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    try {
      await deleteUser(uid);
      await loadUsers();
    } catch (err) {
      console.error(err);
      setError('Failed to delete user.');
    }
  };

  const handleAddUser = async () => {
    if (!newUser.email || !['admin', 'user'].includes(newUser.role)) {
      setError('Enter valid email and role.');
      return;
    }
    try {
      await addUser(newUser);
      await loadUsers();
      setNewUser({ email: '', role: 'user' });
    } catch (err) {
      console.error(err);
      setError('Failed to add user.');
    }
  };

  if (!user) return null;

  return (
    <div className={`p-6 min-h-screen ${darkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-900'}`}>
      <h1 className="text-2xl font-bold mb-6">Profile</h1>
      {error && <p className="text-red-500 mb-4">{error}</p>}

      {user.role !== 'admin' ? (
        <div>
          <p><strong>Email:</strong> {user.email}</p>
          <p><strong>Role:</strong> {user.role}</p>
        </div>
      ) : (
        <div>
          <h2 className="text-xl font-semibold mb-4">Manage Users</h2>

          <table className="w-full border border-gray-300 mb-6">
            <thead className="bg-gray-200">
              <tr>
                <th className="p-2 text-left">Email</th>
                <th className="p-2 text-left">Role</th>
                <th className="p-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.uid || u.email} className="border-t border-gray-300">
                  <td className="p-2">
                    {editing === u.uid ? (
                      <input
                        type="email"
                        defaultValue={u.email}
                        onChange={e => u.email = e.target.value}
                        className="input"
                      />
                    ) : (
                      u.email
                    )}
                  </td>
                  <td className="p-2">
                    {editing === u.uid ? (
                      <select defaultValue={u.role} onChange={e => u.role = e.target.value} className="input">
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                      </select>
                    ) : (
                      u.role
                    )}
                  </td>
                  <td className="p-2 flex gap-2 justify-center">
                    {editing === u.uid ? (
                      <>
                        <button className="btn-green" onClick={() => handleUpdate(u.uid, u)}>Save</button>
                        <button className="btn-gray" onClick={() => setEditing(null)}>Cancel</button>
                      </>
                    ) : (
                      <>
                        <button className="btn-blue" onClick={() => handleEdit(u.uid)}>Edit</button>
                        <button className="btn-red" onClick={() => handleDelete(u.uid)}>Delete</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <h3 className="text-lg font-semibold mb-2">Add New User</h3>
          <div className="flex flex-col sm:flex-row gap-2 mb-6">
            <input
              type="email"
              placeholder="Email"
              value={newUser.email}
              onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
              className="input w-full sm:w-auto"
            />
            <select
              value={newUser.role}
              onChange={(e) => setNewUser(prev => ({ ...prev, role: e.target.value }))}
              className="input w-full sm:w-auto"
            >
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
            <button onClick={handleAddUser} className="btn-blue">Add</button>
          </div>
        </div>
      )}
    </div>
  );
}
