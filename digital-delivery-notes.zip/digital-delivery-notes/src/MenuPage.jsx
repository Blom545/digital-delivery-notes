import { useAuth } from './AuthProvider';
import { useNavigate } from 'react-router-dom';
import { useDarkMode } from './DarkModeContext';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useEffect } from 'react';

export default function MenuPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { darkMode, setDarkMode } = useDarkMode();

  const menuItems = [
    { name: 'Create Delivery Note', path: '/layout/form' },
    { name: 'History', path: '/layout/history' },
    { name: 'Bulk Upload', path: '/layout/bulk-upload' },
    { name: 'Dashboard', path: '/layout/dashboard' },
    { name: 'Profile', path: '/layout/profile' }, // Add this line
  ];

  useEffect(() => {
    if (!loading && !user) {
      console.log('User is null, redirecting to /login');
      navigate('/login');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className={`max-w-6xl mx-auto p-6 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors duration-300 ${darkMode ? 'dark' : ''}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="Top Fruit Logo" className="h-16 object-contain" />
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Main Menu</h1>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {menuItems.map((item) => (
          <button
            key={item.path}
            onClick={() => {
              console.log(`Navigating to ${item.path}`);
              navigate(item.path);
            }}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 text-center transition-colors duration-300"
          >
            {item.name}
          </button>
        ))}
      </div>
    </div>
  );
}