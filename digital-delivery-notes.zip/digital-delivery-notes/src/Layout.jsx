import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthProvider';
import { useDarkMode } from './DarkModeContext';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useEffect, useState, useCallback } from 'react';
import { Dialog, Disclosure, Transition } from '@headlessui/react';
import './Layout.css'; // Import the CSS file

const navigationItems = [
  { path: '/layout/form', label: 'Form', icon: '📋', roles: ['admin', 'user'] },
  { path: '/layout/history', label: 'History', icon: '📜', roles: ['admin', 'user'] },
  { path: '/layout/dashboard', label: 'Dashboard', icon: '📊', roles: ['admin', 'user'] },
  { path: '/layout/bulk-upload', label: 'Bulk Upload', icon: '📤', roles: ['admin', 'user'] },
  { path: '/layout/profile', label: 'Profile', icon: '👤', roles: ['admin', 'user'] }, // New item
];

const SidebarSkeleton = () => (
  <div className="bg-gray-800 text-white p-4 h-full animate-pulse">
    <div className="mb-6">
      <div className="h-12 bg-gray-700 rounded mb-4 w-1/2"></div>
      <div className="h-6 bg-gray-700 rounded w-1/3"></div>
    </div>
    <div>
      {[...Array(5)].map((_, i) => (
        <div key={i} className="mb-2 h-8 bg-gray-700 rounded w-full"></div>
      ))}
    </div>
  </div>
);

const MainSkeleton = () => (
  <div className="flex-1 p-6 bg-gray-50 dark:bg-gray-900 min-h-screen animate-pulse">
    <div className="mb-6">
      <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded w-1/3"></div>
    </div>
    <div className="h-64 bg-gray-300 dark:bg-gray-700 rounded"></div>
  </div>
);

export default function Layout() {
  const { user, logout, loading } = useAuth();
  const navigate = useNavigate();
  const { darkMode, setDarkMode } = useDarkMode();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [isLogoutConfirmOpen, setIsLogoutConfirmOpen] = useState(false);
  const location = useLocation();

  const handleLogout = useCallback(async () => {
    try {
      await logout();
      navigate('/login');
      toast.success('Logged out successfully!', { autoClose: 5000 });
    } catch (error) {
      toast.error(`Logout failed: ${error.message}`, { autoClose: 5000 });
    }
  }, [logout, navigate]);

  const confirmLogout = () => setIsLogoutConfirmOpen(true);

  const updateMobileStatus = () => {
    setIsMobile(window.innerWidth < 768);
    if (window.innerWidth >= 768) setIsSidebarOpen(true); // Reset on desktop
  };

  useEffect(() => {
    window.addEventListener('resize', updateMobileStatus);
    return () => window.removeEventListener('resize', updateMobileStatus);
  }, []);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  const filteredNavItems = navigationItems.filter((item) =>
    item.roles.includes(user?.role || 'user')
  );

  const isMainMenu = location.pathname === '/layout/menu';

  if (loading) {
    return (
      <div className="flex h-screen">
        <SidebarSkeleton />
        <MainSkeleton />
      </div>
    );
  }

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <aside
        className={`sidebar bg-gray-800 text-white dark:bg-gray-900 p-4 transition-all duration-300 fixed z-30 h-full top-0 ${
          isSidebarOpen ? 'w-64' : 'w-16'
        } ${isMobile && !isSidebarOpen ? '-left-64' : ''} ${isMobile && isSidebarOpen ? 'open' : ''}`}
        data-testid="sidebar"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            {isSidebarOpen && (
              <>
                <img src="/logo.png" alt="TopFruit Logo" className="h-10 object-contain mr-2" />
                <h2 className="text-xl font-bold">TopFruit</h2>
              </>
            )}
          </div>
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="text-white hover:text-gray-300 focus:outline-none"
            aria-expanded={isSidebarOpen}
            aria-label={isSidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
          >
            {isSidebarOpen ? '◄' : '►'}
          </button>
        </div>
        <nav>
          <ul>
            {filteredNavItems.map((item) => (
              <li key={item.path} className="mb-2">
                <button
                  onClick={() => {
                    navigate(item.path);
                    if (isMobile) setIsSidebarOpen(false); // Close on mobile nav
                  }}
                  className="w-full text-left p-2 hover:bg-gray-700 rounded flex items-center"
                  aria-label={`Navigate to ${item.label}`}
                >
                  <span className="mr-2">{item.icon}</span>
                  {isSidebarOpen && item.label}
                </button>
              </li>
            ))}
            <li>
              <button
                onClick={confirmLogout}
                className="w-full text-left p-2 hover:bg-gray-700 rounded flex items-center"
                aria-label="Logout"
              >
                <span className="mr-2">🚪</span>
                {isSidebarOpen && 'Logout'}
              </button>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Hamburger Menu for Mobile */}
      <button
        className="hamburger fixed top-4 left-4 z-40 bg-gray-800 text-white p-2 rounded focus:outline-none md:hidden"
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        aria-label={isSidebarOpen ? 'Close menu' : 'Open menu'}
        aria-expanded={isSidebarOpen}
      >
        {isSidebarOpen ? '✖' : '☰'}
      </button>

      {/* Overlay on mobile when sidebar is open */}
      {isMobile && isSidebarOpen && <div className="overlay" onClick={() => setIsSidebarOpen(false)} />}

      {/* Main content */}
      <main
  className={`flex-1 p-6 transition-all duration-300 overflow-y-auto ${
    isMobile ? 'ml-0' : isSidebarOpen ? 'ml-64' : 'ml-16'
  } bg-white text-gray-800 dark:bg-gray-900 dark:text-gray-100`}
>
        <ToastContainer position="top-right" autoClose={5000} />
        <div className="mb-6 flex items-center justify-between flex-wrap">
          <div className="flex items-center gap-4">
            {!isMainMenu && (
              <button
                onClick={() => navigate('/layout/menu')}
                className="bg-gray-300 text-gray-800 hover:bg-gray-400 dark:bg-gray-600 dark:text-white dark:hover:bg-gray-700 px-3 py-1 rounded"
                aria-label="Back to Main Menu"
              >
                Back to Main Menu
              </button>
            )}
            <h1 className="text-2xl font-bold">TopFruit App</h1>
          </div>
          <div className="flex items-center space-x-4 mt-2 md:mt-0">
            {user && (
              <p className="text-sm text-muted">
                Logged in as <strong>{user.email}</strong> ({user.role || 'User'})
              </p>
            )}
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={darkMode}
                onChange={() => setDarkMode(!darkMode)}
                className="sr-only peer"
                aria-label="Toggle dark mode"
              />
              <div className="w-11 h-6 bg-gray-200 dark:bg-gray-700 peer-checked:bg-blue-600 rounded-full relative">
                <div className="absolute top-[2px] left-[2px] w-5 h-5 bg-white rounded-full shadow-md transform peer-checked:translate-x-5 transition" />
              </div>
              <span className="ml-3 text-sm text-default">Dark Mode</span>
            </label>
          </div>
        </div>
        <Outlet />
      </main>

      {/* Logout Confirmation Dialog */}
      <Dialog
        open={isLogoutConfirmOpen}
        onClose={() => setIsLogoutConfirmOpen(false)}
        className="fixed inset-0 z-40 bg-black bg-opacity-50 flex items-center justify-center"
      >
        <Dialog.Panel className="bg-white dark:bg-gray-800 p-6 rounded shadow-lg">
          <Dialog.Title className="text-lg font-bold text-default">Confirm Logout</Dialog.Title>
          <Dialog.Description className="mt-2 text-muted">
            Are you sure you want to log out?
          </Dialog.Description>
          <div className="mt-4 flex justify-end space-x-4">
            <button
              onClick={() => setIsLogoutConfirmOpen(false)}
              className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded hover:bg-gray-300 dark:hover:bg-gray-600"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                setIsLogoutConfirmOpen(false);
                handleLogout();
              }}
              className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
            >
              Logout
            </button>
          </div>
        </Dialog.Panel>
      </Dialog>
    </div>
  );
}