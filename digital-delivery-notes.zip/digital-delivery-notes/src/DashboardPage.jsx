import { useAuth } from './AuthProvider';
import { useEffect, useState, useRef } from 'react';
import { collection, getDocs, query, where, Timestamp } from 'firebase/firestore';
import { db } from './firebase';
import { useNavigate } from 'react-router-dom';
import { useDarkMode } from './DarkModeContext';
import * as XLSX from 'xlsx';

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { darkMode } = useDarkMode();
  const [submissionCount, setSubmissionCount] = useState(0);
  const [seasonCounts, setSeasonCounts] = useState({});
  const [recentSubmissions, setRecentSubmissions] = useState([]);
  const [avgItems, setAvgItems] = useState(0);
  const [loading, setLoading] = useState(true);
  const chartContainerRef = useRef(null);

  useEffect(() => {
    if (!user) {
      console.log('No user, navigating to /');
      navigate('/');
      return;
    }
    const fetchDashboardData = async () => {
      try {
        const q = query(collection(db, 'deliveryNotes'), where('from', '==', user.email));
        const snapshot = await getDocs(q);
        setSubmissionCount(snapshot.size);
        const counts = snapshot.docs.reduce((acc, doc) => {
          const season = doc.data().season;
          acc[season] = (acc[season] || 0) + 1;
          return acc;
        }, {});
        setSeasonCounts(counts);
        const notes = snapshot.docs
          .map(doc => ({ id: doc.id, ...doc.data() }))
          .sort((a, b) => b.createdAt.toDate() - a.createdAt.toDate())
          .slice(0, 5);
        setRecentSubmissions(notes);
        const totalItems = snapshot.docs.reduce((sum, doc) => sum + doc.data().items.length, 0);
        setAvgItems(snapshot.size > 0 ? totalItems / snapshot.size : 0);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchDashboardData();
  }, [user, navigate]);

  const handleExportCSV = async () => {
    const q = query(collection(db, 'deliveryNotes'), where('from', '==', user.email));
    const snapshot = await getDocs(q);
    const data = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Submissions');
    XLSX.writeFile(wb, 'topfruit_submissions.csv');
  };

  useEffect(() => {
    const container = chartContainerRef.current;
    if (container) {
      const canvas = document.createElement('canvas');
      canvas.width = 300;
      canvas.height = 200;
      canvas.setAttribute('willReadFrequently', 'true');
      const ctx = canvas.getContext('2d');
      const data = Object.values(seasonCounts);
      const max = Math.max(...data, 1);
      ctx.fillStyle = 'rgba(59, 130, 246, 0.7)';
      data.forEach((value, index) => {
        const height = (value / max) * 150;
        ctx.fillRect(index * 60 + 20, 200 - height, 40, height);
        ctx.fillStyle = 'black';
        ctx.fillText(value || 0, index * 60 + 30, 190);
      });
      container.innerHTML = '';
      container.appendChild(canvas);
    }
  }, [seasonCounts]);

  return (
    <div className={`max-w-6xl mx-auto p-6 ${darkMode ? 'bg-gray-900 text-gray-200' : 'bg-gray-50 text-gray-800'} min-h-screen`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="Top Fruit Logo" className="h-16 object-contain" />
          <h1 className="text-2xl font-bold text-default">Dashboard</h1>
        </div>
      </div>
      {loading ? (
        <p className="text-muted">Loading...</p>
      ) : (
        <div className={`p-6 rounded-lg shadow-lg ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
          <h2 className="text-xl font-semibold text-default mb-4">Submission Statistics</h2>
          <p className="text-lg">Total Submissions: <span className="font-bold">{submissionCount}</span></p>
          <p className="text-lg mt-2">Average Items per Submission: <span className="font-bold">{avgItems.toFixed(1)}</span></p>
          <div className="mt-4">
            <h3 className="text-lg font-semibold">Submissions by Season</h3>
            <ul className="list-disc pl-5">
              {Object.entries(seasonCounts).map(([season, count]) => (
                <li key={season}>Season {season}: {count}</li>
              ))}
            </ul>
          </div>
          <div className="mt-4">
            <h3 className="text-lg font-semibold">Recent Submissions</h3>
            <ul className="list-disc pl-5">
              {recentSubmissions.map(note => (
                <li key={note.id}>{note.deliveryNumber} - {note.createdAt.toDate().toLocaleDateString()}</li>
              ))}
            </ul>
          </div>
          <div ref={chartContainerRef} className="mt-4 border p-2 rounded"></div>
          <button onClick={handleExportCSV} className="mt-6 btn-blue">
            Export All Data
          </button>
        </div>
      )}
    </div>
  );
}