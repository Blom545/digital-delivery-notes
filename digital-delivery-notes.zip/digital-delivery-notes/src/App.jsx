import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import Layout from './Layout';
import DeliveryNoteForm from './DeliveryNoteForm';
import HistoryPage from './HistoryPage';
import BulkUploadPage from './BulkUploadPage';
import DashboardPage from './DashboardPage';
import MenuPage from './MenuPage';
import LoginPage from './LoginPage';
import Profile from './Profile';
import { AuthProvider, useAuth } from './AuthProvider';
import { DarkModeProvider } from './DarkModeContext';

function App() {
  return (
    <Router>
      <AuthProvider>
        <DarkModeProvider>
          <div className="min-h-screen bg-topfruit-cream dark:bg-topfruit-green text-topfruit-text dark:text-white transition-colors duration-300">
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              
              <Route
                path="/"
                element={
                  <RequireAuth>
                    <Navigate to="/layout/menu" />
                  </RequireAuth>
                }
              />

              <Route
                path="/layout"
                element={
                  <RequireAuth>
                    <Layout />
                  </RequireAuth>
                }
              >
                <Route path="menu" element={<MenuPage />} />
                <Route path="form" element={<DeliveryNoteForm />} />
                <Route path="history" element={<HistoryPage />} />
                <Route path="bulk-upload" element={<BulkUploadPage />} />
                <Route path="dashboard" element={<DashboardPage />} />
                <Route path="/layout/profile" element={<Profile />} />
              </Route>

              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </div>
        </DarkModeProvider>
      </AuthProvider>
    </Router>
  );
}



// 🔐 Authentication wrapper
function RequireAuth({ children }) {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  if (loading) return <div>Loading...</div>;

  return user ? children : null;
}

export default App;