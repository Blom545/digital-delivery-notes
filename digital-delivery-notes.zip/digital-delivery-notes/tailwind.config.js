// tailwind.config.js
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'], // make sure it points to your source folder
  theme: {
    extend: {
      colors: {
        topfruit: {
          green: '#2F4F3E',
          lightgreen: '#88B04B',
          red: '#BE1E2D',
          cream: '#F5F5F3',
          text: '#2B2B2B',
        },
      },
    },
  },
  darkMode: 'class',
  plugins: [],
};
